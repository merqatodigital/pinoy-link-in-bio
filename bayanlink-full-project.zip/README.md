This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

---

## BayanLink — Hyper-Local Link-in-Bio for the Philippines

**BayanLink** is a complete, production-ready Next.js prototype for a Philippines-first "link in bio" tool.

### Key Features Implemented
- **Live dual-panel dashboard**: Merchant Editor (left) + Realistic iPhone mockup preview (right) that updates instantly.
- **Full state reactivity**: Every input (name, bio, avatar, location, verified badge, theme, payments, message template, products) instantly reflects in the phone preview.
- **3 Beautiful Themes**: Pasay Pastel Pop, Vibrant Tropical Eco (default), Manila Minimalist Dark — powered by CSS variables + dynamic styling.
- **Conversational Commerce**: High-visibility Messenger & WhatsApp buttons with pre-filled message simulation (customizable template with [PRODUCT] placeholder).
- **Rich Product Cards**: Instead of plain links — beautiful cards with emoji visuals, prices in ₱, and "Buy via GCash/Maya" CTAs.
- **Native-like Payment Sheet**: Slide-up modal with mock QR Ph, payment method options (respecting your toggles), and full success flow.
- **Trust & Logistics**: Legit Check, Shopee/Lazada links, and working Courier Tracking widget (J&T, Lalamove, Flash Express) with realistic mock statuses.
- **Mobile-first & Data-light**: Strict 340px phone frame, optimized SVGs, system fonts, no heavy external assets.
- **PH Ecosystem Native**: GCash, Maya, QR Ph, COD, popular local couriers, Shopee/Lazada integration points, Taglish messaging.

### How to Run
```bash
npm install
npm run dev
```
Open http://localhost:3000

Edit anything in the left panel — watch the phone preview react in real time. Perfect for rapid prototyping or client demos.

### Architecture Notes
- Pure React + TypeScript + Tailwind (no extra runtime deps)
- All icons are optimized inline SVGs
- Fully commented, clean, production-ready code ready to extend (add real backend, auth, database, actual payment APIs, etc.)
- Designed with your Palawan resort & tourism projects in mind — easy to adapt for immersive resort sites or local merchant tools.

Built with ❤️ for the Philippine creator & e-commerce ecosystem.


## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
