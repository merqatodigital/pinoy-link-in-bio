"use client";

import React, { useState, useMemo } from 'react';

// ============================================
// TYPES & INTERFACES
// ============================================
interface Product {
  id: number;
  title: string;
  subtitle: string;
  price: number;
}

interface Theme {
  id: string;
  label: string;
  description: string;
  primary: string;
  accentLight: string;
  bg: string;
  cardBg: string;
  textPrimary: string;
  textMuted: string;
}

interface ChatPlatform {
  name: string;
  icon: React.ReactNode;
  color: string;
}

// ============================================
// THEME DEFINITIONS - Hyper-local PH vibes
// ============================================
const themes: Theme[] = [
  {
    id: 'pasay-pastel',
    label: 'Pasay Pastel Pop',
    description: 'Soft pastels, friendly & youthful',
    primary: '#e11d48',      // Rose-600 - vibrant yet soft
    accentLight: '#fda4af',
    bg: '#fff1f2',
    cardBg: '#ffffff',
    textPrimary: '#4c1d95',
    textMuted: '#6b7280',
  },
  {
    id: 'tropical-eco',
    label: 'Vibrant Tropical Eco',
    description: 'Island greens & ocean energy',
    primary: '#059669',      // Emerald-600
    accentLight: '#34d399',
    bg: '#ecfdf5',
    cardBg: '#ffffff',
    textPrimary: '#064e3b',
    textMuted: '#4b5563',
  },
  {
    id: 'manila-minimal',
    label: 'Manila Minimalist Dark',
    description: 'Clean, modern, high-contrast',
    primary: '#1f2937',      // Slate-800
    accentLight: '#4b5563',
    bg: '#0f172a',
    cardBg: '#1e2937',
    textPrimary: '#f1f5f9',
    textMuted: '#94a3b8',
  },
];

// Default products - realistic for PH merchant / resort-adjacent
const defaultProducts: Product[] = [
  { id: 101, title: "Beachfront Cottage Stay", subtitle: "2 nights • San Vicente, Palawan", price: 4500 },
  { id: 102, title: "Island Hopping Adventure", subtitle: "Full day tour • Max 6 pax", price: 1850 },
  { id: 103, title: "Fresh Seafood Platter", subtitle: "For 2 • Grilled & kinilaw", price: 980 },
  { id: 104, title: "Handwoven Abaca Bag", subtitle: "Local artisan • Sustainable", price: 650 },
];

// Default pre-filled message template (customizable)
const defaultMessengerTemplate = 
  "Hi! I'm interested in ordering [PRODUCT]. Pwede po ba via GCash or Maya? Salamat!";

// ============================================
// INLINE SVG ICONS (Zero external deps - optimized)
// ============================================
const IconCheck = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5 10l7-7m0 0l7 7" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18" />
  </svg>
);

const IconMapPin = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.25}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314-11.314z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const IconStar = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="currentColor" viewBox="0 0 24 24">
    <path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
  </svg>
);

const IconMessage = ({ className = "w-5 h-5" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
  </svg>
);

const IconWhatsApp = ({ className = "w-5 h-5" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="currentColor" viewBox="0 0 24 24">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.198-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.372-.025-.521-.075-.149-.67-.966-.916-1.316-.247-.35-.497-.297-.67-.297-.173 0-.372.074-.57.223-.198.149-.767.746-.94.92-.173.174-.347.223-.52.075-.173-.149-.52-.52-.52-.67 0-.149.05-.372.223-.52.174-.149 1.07-.746 1.316-.92.247-.174.372-.223.52-.075.149.149.52.52.67.746.149.223.223.372.372.52.149.149.298.223.446.223.149 0 .298-.074.446-.223.149-.149.223-.298.372-.446.149-.149.223-.223.372-.223.149 0 .298.074.446.223.149.149.223.298.372.446.149.149.223.298.372.446z" />
    <path d="M12 2C6.48 2 2 6.48 2 12c0 1.84.5 3.57 1.38 5.06L2 22l4.94-1.38C8.43 21.5 10.16 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm0 18c-1.6 0-3.1-.48-4.35-1.3l-.31-.2-2.94.82.82-2.94-.2-.31C4.48 15.1 4 13.6 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8z" />
  </svg>
);

const IconTruck = ({ className = "w-4 h-4" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1" />
  </svg>
);

const IconQR = ({ className = "w-16 h-16" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.875c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5A1.125 1.125 0 013.75 9.375v-4.5zM3.75 14.625c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5a1.125 1.125 0 01-1.125-1.125v-4.5zM13.5 4.875c0-.621.504-1.125 1.125-1.125h4.5c.621 0 1.125.504 1.125 1.125v4.5c0 .621-.504 1.125-1.125 1.125h-4.5A1.125 1.125 0 0113.5 9.375v-4.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 6.75h.75v.75h-.75v-.75zM6.75 16.5h.75v.75h-.75v-.75zM16.5 6.75h.75v.75h-.75v-.75z" />
  </svg>
);

const IconGCash = ({ className = "w-5 h-5" }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="#00A651">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
  </svg>
);

// ============================================
// MAIN COMPONENT
// ============================================
export default function BayanLink() {
  // --- STATE MANAGEMENT (All reactive & connected to preview) ---
  const [businessName, setBusinessName] = useState("Palawan Pantry Co.");
  const [bio, setBio] = useState("Fresh island flavors & handcrafted goods from San Vicente. Support local, taste the bayan.");
  const [avatarUrl, setAvatarUrl] = useState("https://picsum.photos/id/1005/200/200"); // Reliable demo image
  const [location, setLocation] = useState("San Vicente, Palawan");
  const [isVerified, setIsVerified] = useState(true);

  const [currentTheme, setCurrentTheme] = useState<Theme>(themes[1]); // Default: Tropical Eco

  // Payment toggles
  const [payments, setPayments] = useState({
    gcash: true,
    maya: true,
    qrph: true,
    cod: false,
  });

  const [messengerTemplate, setMessengerTemplate] = useState(defaultMessengerTemplate);

  // Products state - fully editable
  const [products, setProducts] = useState<Product[]>(defaultProducts);

  // Modal / Sheet states
  const [showPaymentSheet, setShowPaymentSheet] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const [showChatModal, setShowChatModal] = useState(false);
  const [chatPlatform, setChatPlatform] = useState<'messenger' | 'whatsapp'>('messenger');

  const [trackingResult, setTrackingResult] = useState<string | null>(null);
  const [selectedCourier, setSelectedCourier] = useState("J&T Express");
  const [trackingNumber, setTrackingNumber] = useState("JTX-784291");

  // --- DERIVED / HELPERS ---
  const themeStyle = useMemo(() => ({
    '--accent': currentTheme.primary,
    '--accent-light': currentTheme.accentLight,
    backgroundColor: currentTheme.bg,
    color: currentTheme.textPrimary,
  } as React.CSSProperties), [currentTheme]);

  const cardStyle = useMemo(() => ({
    backgroundColor: currentTheme.cardBg,
    color: currentTheme.textPrimary,
  } as React.CSSProperties), [currentTheme]);

  const isDarkTheme = currentTheme.id === 'manila-minimal';

  // Generate dynamic pre-filled message for demo
  const getPrefilledMessage = (productTitle?: string) => {
    const productRef = productTitle || "[PRODUCT]";
    return messengerTemplate.replace("[PRODUCT]", productRef);
  };

  // --- PRODUCT CRUD ---
  const addProduct = () => {
    const newProduct: Product = {
      id: Date.now(),
      title: "New Item",
      subtitle: "Short description here",
      price: 299,
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: number, field: keyof Product, value: string | number) => {
    setProducts(prev =>
      prev.map(p =>
        p.id === id ? { ...p, [field]: value } : p
      )
    );
  };

  const deleteProduct = (id: number) => {
    if (products.length === 1) {
      alert("At least one product is required for the demo.");
      return;
    }
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  // --- PAYMENT SHEET HANDLERS ---
  const openPaymentSheet = (product: Product) => {
    setSelectedProduct(product);
    setShowPaymentSheet(true);
    setPaymentSuccess(false);
    setTrackingResult(null); // reset any previous
  };

  const closePaymentSheet = () => {
    setShowPaymentSheet(false);
    setTimeout(() => {
      setSelectedProduct(null);
      setPaymentSuccess(false);
    }, 300);
  };

  const handleConfirmPayment = () => {
    // Simulate real payment processing (GCash/Maya style)
    setPaymentSuccess(true);
    // In real app: would call backend / GCash API here
    setTimeout(() => {
      // Auto close after success or keep open
    }, 2200);
  };

  // --- CHAT / MESSENGER SIMULATION ---
  const openChatModal = (platform: 'messenger' | 'whatsapp') => {
    setChatPlatform(platform);
    setShowChatModal(true);
  };

  const closeChatModal = () => {
    setShowChatModal(false);
  };

  const simulateSendMessage = () => {
    // In production this would open actual fb.me / wa.me with prefilled text
    const message = getPrefilledMessage(selectedProduct?.title);
    alert(`✅ Message sent via ${chatPlatform === 'messenger' ? 'Messenger' : 'WhatsApp'}!\n\n"${message}"\n\n(In real use: opens native app with pre-filled text)`);
    closeChatModal();
  };

  // --- TRACKING WIDGET ---
  const handleTrackPackage = () => {
    // Mock realistic tracking responses
    const mockStatuses: Record<string, string> = {
      "J&T Express": "📦 Picked up in Puerto Princesa • In transit to San Vicente hub • ETA: Tomorrow 2PM",
      "Lalamove": "🛵 Driver assigned (Juan D.) • En route • 4.2km away • Arriving in ~18 mins",
      "Flash Express": "🚚 Out for delivery • Last scan: Brgy. Sto. Niño • Contact driver: 0917-XXX-XXXX",
    };
    const status = mockStatuses[selectedCourier] || "Package is being prepared. Thank you for your patience!";
    setTrackingResult(status);
  };

  // --- THEME CHANGER ---
  const changeTheme = (theme: Theme) => {
    setCurrentTheme(theme);
  };

  // --- PAYMENT TOGGLE ---
  const togglePayment = (key: keyof typeof payments) => {
    setPayments(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="min-h-screen bg-zinc-950 text-white selection:bg-emerald-500/30">
      {/* Top Navigation / Branding */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-zinc-950/95 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-6 flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-emerald-600 text-white font-bold text-xl tracking-tighter">B</div>
            <div>
              <div className="font-semibold tracking-tight text-xl">BayanLink</div>
              <div className="text-[10px] text-emerald-400 -mt-1">LINK IN BIO • TUNAY NA PILIPINO</div>
            </div>
          </div>

          <div className="flex items-center gap-3 text-sm">
            <div className="hidden md:flex items-center gap-2 rounded-full bg-white/5 px-4 py-1.5 text-xs text-white/60">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Optimized for 3G/4G • GCash-first
            </div>
            <button 
              onClick={() => {
                // Reset to defaults
                setBusinessName("Palawan Pantry Co.");
                setBio("Fresh island flavors & handcrafted goods from San Vicente. Support local, taste the bayan.");
                setProducts(defaultProducts);
                setCurrentTheme(themes[1]);
                setIsVerified(true);
                setPayments({ gcash: true, maya: true, qrph: true, cod: false });
                setMessengerTemplate(defaultMessengerTemplate);
                setTrackingResult(null);
              }}
              className="rounded-full border border-white/20 px-4 py-1.5 text-xs hover:bg-white/5 active:bg-white/10 transition-colors"
            >
              Reset Demo
            </button>
            <button 
              onClick={() => alert("In production: Copies your unique BayanLink URL to clipboard + shows QR")}
              className="rounded-full bg-white text-zinc-950 px-5 py-1.5 text-xs font-medium hover:bg-white/90 active:bg-white transition-all flex items-center gap-2"
            >
              Copy Link
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 pb-16 pt-8 lg:px-8">
        {/* Hero / Intro */}
        <div className="mb-10 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/5 px-4 py-1 text-xs tracking-[2px] text-emerald-400 mb-3">FOR CREATORS • MERCHANTS • RESORTS</div>
          <h1 className="text-5xl lg:text-6xl font-semibold tracking-tighter">One link.<br />Real bayan connections.</h1>
          <p className="mt-3 max-w-md mx-auto lg:mx-0 text-lg text-white/60">Hyper-local link-in-bio built for GCash, conversational commerce, and slow provincial data.</p>
        </div>

        {/* MAIN DASHBOARD GRID */}
        <div className="grid lg:grid-cols-12 gap-8">
          
          {/* ========== MERCHANT EDITOR DASHBOARD (LEFT) ========== */}
          <div className="lg:col-span-5 xl:col-span-5">
            <div className="editor-panel sticky top-20 rounded-3xl bg-zinc-900 border border-white/10 p-7">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="font-semibold text-xl tracking-tight">Merchant Editor</div>
                  <div className="text-xs text-white/50">Changes update live in the preview →</div>
                </div>
                <div className="text-[10px] px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">LIVE</div>
              </div>

              {/* 1. BRAND PROFILE */}
              <div className="mb-8">
                <div className="text-xs uppercase tracking-widest text-white/50 mb-3">BRAND PROFILE</div>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-white/60 block mb-1.5">Business Name</label>
                    <input
                      type="text"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      className="w-full rounded-2xl bg-zinc-950 border border-white/10 px-4 py-3 text-lg font-medium focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-white/60 block mb-1.5">Short Bio</label>
                    <textarea
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={3}
                      className="w-full rounded-2xl bg-zinc-950 border border-white/10 px-4 py-3 text-sm resize-y focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-white/60 block mb-1.5">Avatar URL</label>
                      <input
                        type="text"
                        value={avatarUrl}
                        onChange={(e) => setAvatarUrl(e.target.value)}
                        placeholder="https://picsum.photos/..."
                        className="w-full rounded-2xl bg-zinc-950 border border-white/10 px-4 py-2.5 text-sm focus:outline-none focus:border-emerald-500/50"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-white/60 block mb-1.5">Location</label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="w-full rounded-2xl bg-zinc-950 border border-white/10 px-4 py-2.5 text-sm focus:outline-none focus:border-emerald-500/50"
                      />
                    </div>
                  </div>

                  {/* Verified Toggle */}
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-3">
                      <div className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${isVerified ? 'bg-emerald-500/10 text-emerald-400' : 'bg-white/5 text-white/50'}`}>
                        <IconCheck className="w-3.5 h-3.5" /> {isVerified ? "VERIFIED LEGIT SELLER" : "NOT VERIFIED"}
                      </div>
                    </div>
                    <label className="switch">
                      <input 
                        type="checkbox" 
                        checked={isVerified} 
                        onChange={(e) => setIsVerified(e.target.checked)} 
                      />
                      <span className="slider"></span>
                    </label>
                  </div>
                </div>
              </div>

              {/* 2. THEME SWITCHER */}
              <div className="mb-8">
                <div className="text-xs uppercase tracking-widest text-white/50 mb-3">THEME</div>
                <div className="grid grid-cols-3 gap-3">
                  {themes.map((theme) => (
                    <button
                      key={theme.id}
                      onClick={() => changeTheme(theme)}
                      className={`theme-card text-left rounded-2xl p-3 border transition-all ${currentTheme.id === theme.id ? 'active border-emerald-500' : 'border-white/10 hover:border-white/20'}`}
                      style={{ '--accent': theme.primary } as React.CSSProperties}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: theme.primary }} />
                        <div className="font-medium text-sm tracking-tight">{theme.label.split(' ')[0]}</div>
                      </div>
                      <div className="text-[10px] text-white/50 leading-tight line-clamp-2">{theme.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. PAYMENT SETUP */}
              <div className="mb-8">
                <div className="text-xs uppercase tracking-widest text-white/50 mb-3">PAYMENT METHODS ENABLED</div>
                <div className="space-y-3 rounded-2xl bg-zinc-950/70 p-4 border border-white/5">
                  {[
                    { key: 'gcash' as const, label: 'GCash', icon: <IconGCash className="w-4 h-4" /> },
                    { key: 'maya' as const, label: 'Maya', icon: <span className="text-[#00AEEF] text-xs font-bold">M</span> },
                    { key: 'qrph' as const, label: 'QR Ph (BancNet)', icon: <IconQR className="w-4 h-4" /> },
                    { key: 'cod' as const, label: 'Cash on Delivery', icon: <span>₱</span> },
                  ].map(({ key, label, icon }) => (
                    <div key={key} className="flex items-center justify-between">
                      <div className="flex items-center gap-3 text-sm">
                        <div className="w-7 flex justify-center">{icon}</div>
                        <span>{label}</span>
                      </div>
                      <label className="switch">
                        <input 
                          type="checkbox" 
                          checked={payments[key]} 
                          onChange={() => togglePayment(key)} 
                        />
                        <span className="slider"></span>
                      </label>
                    </div>
                  ))}
                </div>
                <p className="text-[10px] text-white/40 mt-2 px-1">Only enabled methods appear in the payment sheet.</p>
              </div>

              {/* 4. MESSAGING FLOW EDITOR */}
              <div className="mb-8">
                <div className="text-xs uppercase tracking-widest text-white/50 mb-3">CONVERSATIONAL COMMERCE</div>
                <label className="text-xs text-white/60 block mb-1.5">Pre-filled Messenger / WhatsApp message template</label>
                <textarea
                  value={messengerTemplate}
                  onChange={(e) => setMessengerTemplate(e.target.value)}
                  rows={3}
                  className="w-full rounded-2xl bg-zinc-950 border border-white/10 px-4 py-3 text-sm font-mono resize-y focus:outline-none focus:border-emerald-500/50"
                  placeholder="Hi! Interested in [PRODUCT]..."
                />
                <p className="text-[10px] text-white/40 mt-1.5 px-1">Use <span className="font-mono">[PRODUCT]</span> as placeholder. It gets replaced automatically in previews.</p>
              </div>

              {/* 5. PRODUCTS MANAGER */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="text-xs uppercase tracking-widest text-white/50">PRODUCTS / OFFERS</div>
                  <button 
                    onClick={addProduct}
                    className="flex items-center gap-1.5 text-xs rounded-full bg-white/5 hover:bg-white/10 active:bg-white/5 px-4 py-1.5 border border-white/10 transition-colors"
                  >
                    + Add Product
                  </button>
                </div>

                <div className="space-y-3 max-h-[420px] overflow-auto pr-1 custom-scroll">
                  {products.map((product, index) => (
                    <div key={product.id} className="rounded-2xl border border-white/10 bg-zinc-950 p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="text-xs text-white/40">ITEM #{index + 1}</div>
                        <button 
                          onClick={() => deleteProduct(product.id)}
                          className="text-red-400/70 hover:text-red-400 text-xs px-2 py-0.5 rounded hover:bg-red-500/10"
                        >
                          Remove
                        </button>
                      </div>
                      
                      <div className="space-y-3">
                        <input
                          type="text"
                          value={product.title}
                          onChange={(e) => updateProduct(product.id, 'title', e.target.value)}
                          className="w-full bg-transparent border-b border-white/10 pb-1 text-base font-medium focus:outline-none focus:border-emerald-500/40"
                          placeholder="Product title"
                        />
                        <input
                          type="text"
                          value={product.subtitle}
                          onChange={(e) => updateProduct(product.id, 'subtitle', e.target.value)}
                          className="w-full bg-transparent border-b border-white/10 pb-1 text-sm text-white/70 focus:outline-none focus:border-emerald-500/40"
                          placeholder="Short description"
                        />
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 text-lg font-medium">₱</span>
                          <input
                            type="number"
                            value={product.price}
                            onChange={(e) => updateProduct(product.id, 'price', parseInt(e.target.value) || 0)}
                            className="w-28 bg-transparent border-b border-white/10 pb-1 text-xl font-semibold focus:outline-none focus:border-emerald-500/40"
                          />
                          <span className="text-xs text-white/40">PHP</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-[10px] text-center text-white/30 mt-3">Products appear instantly in the phone preview.</p>
              </div>
            </div>
          </div>

          {/* ========== LIVE MOBILE PHONE MOCKUP PREVIEW (RIGHT) ========== */}
          <div className="lg:col-span-7 xl:col-span-7 flex justify-center lg:justify-start">
            <div className="relative">
              {/* Phone Bezel / Frame */}
              <div className="phone-frame relative mx-auto w-[340px] rounded-[3.25rem] border-[14px] border-zinc-900 bg-zinc-900 p-2 shadow-2xl ring-1 ring-white/5">
                {/* Dynamic Island / Notch */}
                <div className="absolute left-1/2 top-4 z-10 h-7 w-36 -translate-x-1/2 rounded-full bg-black" />

                {/* Inner Screen Content */}
                <div 
                  className="phone-content relative h-[620px] w-full overflow-y-auto rounded-[2.35rem] border border-white/10 bg-white text-zinc-950 shadow-inner flex flex-col"
                  style={themeStyle}
                >
                  {/* Status Bar */}
                  <div className="flex h-9 items-center justify-between px-6 pt-3 text-[10px] font-medium tracking-[1px] text-black/60 z-20" style={{ color: isDarkTheme ? '#64748b' : undefined }}>
                    <div>9:41</div>
                    <div className="flex items-center gap-1">100% <div className="h-2.5 w-4 rounded-sm border border-current" /></div>
                  </div>

                  {/* PROFILE HEADER */}
                  <div className="px-6 pt-2 pb-5">
                    <div className="flex items-start gap-4">
                      {/* Avatar */}
                      <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-2xl ring-2 ring-white/80 shadow-md" style={{ backgroundColor: currentTheme.primary + '20' }}>
                        <img 
                          src={avatarUrl} 
                          alt={businessName} 
                          className="h-full w-full object-cover"
                          onError={(e) => {
                            // Fallback to nice gradient + initials
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            const parent = target.parentElement;
                            if (parent) {
                              parent.innerHTML = `<div class="h-full w-full flex items-center justify-center text-3xl font-bold" style="color: ${currentTheme.primary}">${businessName.split(' ').map(w => w[0]).join('').slice(0,2)}</div>`;
                            }
                          }}
                        />
                      </div>

                      <div className="flex-1 min-w-0 pt-1">
                        <div className="flex items-center gap-2">
                          <h2 className="font-semibold text-2xl tracking-tighter truncate" style={{ color: currentTheme.textPrimary }}>{businessName}</h2>
                          {isVerified && (
                            <div className="mt-1 inline-flex items-center rounded-full bg-emerald-500 px-1.5 py-px text-[9px] font-bold text-white tracking-wider shadow">VERIFIED</div>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 text-xs mt-0.5" style={{ color: currentTheme.textMuted }}>
                          <IconMapPin className="w-3.5 h-3.5" /> {location}
                        </div>
                        <p className="mt-2 text-[13px] leading-snug pr-2" style={{ color: currentTheme.textPrimary }}>{bio}</p>
                      </div>
                    </div>
                  </div>

                  {/* CONVERSATIONAL ANCHORS - High visibility */}
                  <div className="px-6 pb-5 grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => openChatModal('messenger')}
                      className="btn-accent flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold shadow active:scale-[0.985] transition-all"
                    >
                      <IconMessage className="w-4 h-4" /> Message on Messenger
                    </button>
                    <button 
                      onClick={() => openChatModal('whatsapp')}
                      className="flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold shadow active:scale-[0.985] transition-all border"
                      style={{ 
                        backgroundColor: '#25D366', 
                        color: 'white',
                        borderColor: '#25D366'
                      }}
                    >
                      <IconWhatsApp className="w-4 h-4" /> Chat on WhatsApp
                    </button>
                  </div>

                  {/* PRODUCTS / OFFERS GRID */}
                  <div className="flex-1 px-6 pb-6">
                    <div className="flex items-baseline justify-between mb-3 px-1">
                      <div className="font-semibold tracking-tight" style={{ color: currentTheme.textPrimary }}>Available Now</div>
                      <div className="text-[10px] text-black/40">Tap to buy</div>
                    </div>

                    <div className="grid grid-cols-1 gap-3">
                      {products.map((product) => (
                        <div 
                          key={product.id} 
                          className="product-card group rounded-3xl border p-4 cursor-pointer active:scale-[0.985] transition-all"
                          style={{ 
                            ...cardStyle,
                            borderColor: isDarkTheme ? '#334155' : '#e5e7eb'
                          }}
                          onClick={() => openPaymentSheet(product)}
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1 pr-4">
                              <div className="font-semibold tracking-tight text-[15px] leading-tight mb-0.5" style={{ color: currentTheme.textPrimary }}>{product.title}</div>
                              <div className="text-xs mb-3" style={{ color: currentTheme.textMuted }}>{product.subtitle}</div>
                              
                              <div className="flex items-baseline gap-1">
                                <span className="text-2xl font-semibold tabular-nums tracking-tighter" style={{ color: currentTheme.primary }}>₱{product.price.toLocaleString()}</span>
                              </div>
                            </div>

                            {/* Product visual accent */}
                            <div 
                              className="h-14 w-14 flex-shrink-0 rounded-2xl flex items-center justify-center text-3xl shadow-inner"
                              style={{ backgroundColor: currentTheme.primary + '15', color: currentTheme.primary }}
                            >
                              {product.title.toLowerCase().includes('cottage') || product.title.toLowerCase().includes('stay') ? '🏝️' : 
                               product.title.toLowerCase().includes('island') ? '🚤' : 
                               product.title.toLowerCase().includes('seafood') ? '🦐' : '👜'}
                            </div>
                          </div>

                          <button 
                            onClick={(e) => { e.stopPropagation(); openPaymentSheet(product); }}
                            className="mt-4 w-full rounded-2xl py-2.5 text-xs font-semibold tracking-wider active:opacity-90 transition-all flex items-center justify-center gap-2"
                            style={{ 
                              backgroundColor: currentTheme.primary, 
                              color: 'white' 
                            }}
                          >
                            BUY VIA GCASH / MAYA
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* TRUST SIGNALS + COURIER TRACKING */}
                  <div className="mt-auto border-t px-6 py-5 text-sm" style={{ borderColor: isDarkTheme ? '#334155' : '#f1f5f9', backgroundColor: isDarkTheme ? '#0f172a' : '#f8fafc' }}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="trust-badge inline-flex items-center gap-1 rounded-full px-3 py-0.5 text-xs font-medium text-amber-700">
                        <IconStar className="w-3.5 h-3.5 text-amber-500" /> 4.96 • 2.8k reviews
                      </div>
                      <div className="text-[10px] text-black/40">Legit Check ✓</div>
                    </div>

                    <div className="flex gap-2 mb-4">
                      <button 
                        onClick={() => alert("In real app: Opens your Shopee store in new tab")}
                        className="flex-1 rounded-2xl border py-2 text-xs font-medium active:bg-black/5 transition-colors"
                        style={{ borderColor: isDarkTheme ? '#475569' : '#e2e8f0', color: currentTheme.textPrimary }}
                      >
                        View on Shopee
                      </button>
                      <button 
                        onClick={() => alert("In real app: Opens your Lazada store")}
                        className="flex-1 rounded-2xl border py-2 text-xs font-medium active:bg-black/5 transition-colors"
                        style={{ borderColor: isDarkTheme ? '#475569' : '#e2e8f0', color: currentTheme.textPrimary }}
                      >
                        View on Lazada
                      </button>
                    </div>

                    {/* Courier Tracking Widget */}
                    <div>
                      <div className="text-xs font-medium mb-2 flex items-center gap-2" style={{ color: currentTheme.textMuted }}>
                        <IconTruck /> TRACK YOUR ORDER
                      </div>
                      <div className="flex gap-2">
                        <select 
                          value={selectedCourier} 
                          onChange={(e) => setSelectedCourier(e.target.value)}
                          className="flex-1 rounded-2xl border bg-white/80 px-3 py-2 text-xs focus:outline-none"
                          style={{ borderColor: isDarkTheme ? '#475569' : '#e2e8f0', color: '#111827' }}
                        >
                          <option>J&amp;T Express</option>
                          <option>Lalamove</option>
                          <option>Flash Express</option>
                        </select>
                        <input 
                          type="text" 
                          value={trackingNumber} 
                          onChange={(e) => setTrackingNumber(e.target.value)}
                          className="w-28 rounded-2xl border bg-white/80 px-3 py-2 text-xs font-mono focus:outline-none"
                          style={{ borderColor: isDarkTheme ? '#475569' : '#e2e8f0', color: '#111827' }}
                        />
                        <button 
                          onClick={handleTrackPackage}
                          className="rounded-2xl px-4 text-xs font-semibold active:opacity-80 transition-all"
                          style={{ backgroundColor: currentTheme.primary, color: 'white' }}
                        >
                          Track
                        </button>
                      </div>
                      {trackingResult && (
                        <div className="mt-3 rounded-2xl bg-white/60 p-3 text-xs leading-snug border" style={{ borderColor: isDarkTheme ? '#475569' : '#e2e8f0', color: '#334155' }}>
                          {trackingResult}
                        </div>
                      )}
                    </div>

                    <div className="mt-5 text-center">
                      <div className="text-[9px] tracking-[1.5px] text-black/30">POWERED BY BAYANLINK • BUILT FOR THE PHILIPPINES</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Subtle label under phone */}
              <div className="mt-3 text-center text-[10px] text-white/30 tracking-widest">LIVE PREVIEW • MOBILE-FIRST • DATA-LIGHT</div>
            </div>
          </div>
        </div>
      </div>

      {/* ========== PAYMENT TRANSACTION SHEET (Native-like) ========== */}
      {showPaymentSheet && selectedProduct && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70" onClick={closePaymentSheet}>
          <div 
            className="sheet w-full max-w-[380px] rounded-t-3xl bg-white p-6 pb-10 text-zinc-950 shadow-2xl"
            onClick={e => e.stopPropagation()}
            style={{ backgroundColor: currentTheme.cardBg, color: currentTheme.textPrimary }}
          >
            <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-black/10" />

            {!paymentSuccess ? (
              <>
                <div className="flex justify-between items-start mb-5">
                  <div>
                    <div className="text-xs text-black/50">CONFIRM YOUR ORDER</div>
                    <div className="text-2xl font-semibold tracking-tight pr-8">{selectedProduct.title}</div>
                  </div>
                  <button onClick={closePaymentSheet} className="text-3xl leading-none text-black/30 hover:text-black/60">×</button>
                </div>

                <div className="mb-6 rounded-2xl border p-4" style={{ borderColor: isDarkTheme ? '#334155' : '#e5e7eb' }}>
                  <div className="flex justify-between text-sm">
                    <span>Total Amount</span>
                    <span className="font-semibold tabular-nums text-2xl tracking-tighter">₱{selectedProduct.price}</span>
                  </div>
                  <div className="text-[10px] text-black/50 mt-0.5">Inclusive of all fees • Instant confirmation</div>
                </div>

                {/* Payment Options */}
                <div className="mb-6">
                  <div className="text-xs uppercase tracking-widest mb-2 text-black/50">CHOOSE PAYMENT METHOD</div>
                  <div className="space-y-2">
                    {payments.gcash && (
                      <div className="flex items-center gap-3 rounded-2xl border p-4 active:bg-zinc-50" style={{ borderColor: '#10b981' }}>
                        <IconGCash className="w-6 h-6" /> 
                        <div className="flex-1"><div className="font-medium">GCash</div><div className="text-xs text-black/50">Instant • Most popular</div></div>
                        <div className="text-emerald-600 text-xs font-medium">RECOMMENDED</div>
                      </div>
                    )}
                    {payments.maya && (
                      <div className="flex items-center gap-3 rounded-2xl border p-4 active:bg-zinc-50" style={{ borderColor: '#00AEEF' }}>
                        <div className="w-6 h-6 rounded bg-[#00AEEF] text-white flex items-center justify-center text-[10px] font-bold">M</div>
                        <div className="flex-1"><div className="font-medium">Maya</div><div className="text-xs text-black/50">Fast checkout</div></div>
                      </div>
                    )}
                    {payments.qrph && (
                      <div className="flex items-center gap-3 rounded-2xl border p-4 active:bg-zinc-50">
                        <IconQR className="w-5 h-5" /> 
                        <div className="flex-1"><div className="font-medium">Scan QR Ph</div><div className="text-xs text-black/50">Any bank app • BancNet</div></div>
                      </div>
                    )}
                    {payments.cod && (
                      <div className="flex items-center gap-3 rounded-2xl border p-4 active:bg-zinc-50">
                        <span className="text-xl">₱</span>
                        <div className="flex-1"><div className="font-medium">Cash on Delivery</div><div className="text-xs text-black/50">Pay when you receive</div></div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Mock QR + Fields */}
                <div className="qr-container mb-6 rounded-3xl p-5 text-center">
                  <div className="mx-auto mb-3 flex justify-center"><IconQR className="w-20 h-20 text-black/80" /></div>
                  <div className="text-xs tracking-widest text-black/60 mb-1">SCAN TO PAY INSTANTLY</div>
                  <div className="font-mono text-xs text-black/40">REF: BAYAN-{Date.now().toString().slice(-8)}</div>
                  <div className="mt-4 text-[10px] text-black/50">Open GCash or Maya → Scan → Confirm</div>
                </div>

                <button 
                  onClick={handleConfirmPayment}
                  className="w-full rounded-2xl py-4 text-base font-semibold tracking-wider shadow-lg active:scale-[0.985] transition-all"
                  style={{ backgroundColor: currentTheme.primary, color: 'white' }}
                >
                  CONFIRM &amp; PAY ₱{selectedProduct.price}
                </button>
                <p className="text-center text-[10px] text-black/40 mt-3">Secure • Encrypted • Powered by BayanLink</p>
              </>
            ) : (
              // SUCCESS STATE
              <div className="py-8 text-center">
                <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full" style={{ backgroundColor: currentTheme.primary + '15' }}>
                  <div className="text-6xl" style={{ color: currentTheme.primary }}>✓</div>
                </div>
                <div className="text-3xl font-semibold tracking-tighter mb-1">Payment Successful!</div>
                <div className="text-emerald-600 mb-6">Thank you! Your order has been confirmed.</div>

                <div className="mx-auto max-w-[260px] rounded-2xl bg-black/5 p-4 text-left text-sm">
                  <div className="font-mono text-xs text-black/50 mb-2">ORDER #{(Date.now() % 1000000).toString().padStart(6, '0')}</div>
                  <div>{selectedProduct.title}</div>
                  <div className="font-semibold mt-1">₱{selectedProduct.price} • Paid via GCash</div>
                </div>

                <button 
                  onClick={closePaymentSheet} 
                  className="mt-8 w-full rounded-2xl border py-3 text-sm font-medium active:bg-black/5"
                >
                  Done — Back to Shop
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========== CHAT MODAL (Messenger / WhatsApp Simulation) ========== */}
      {showChatModal && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-6" onClick={closeChatModal}>
          <div 
            className="modal w-full max-w-md rounded-3xl bg-white p-6 text-zinc-950 shadow-xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center gap-3">
                {chatPlatform === 'messenger' ? <IconMessage className="w-6 h-6 text-[#0084FF]" /> : <IconWhatsApp className="w-6 h-6 text-[#25D366]" />}
                <div>
                  <div className="font-semibold">Chat with {businessName}</div>
                  <div className="text-xs text-black/50">via {chatPlatform === 'messenger' ? 'Facebook Messenger' : 'WhatsApp'}</div>
                </div>
              </div>
              <button onClick={closeChatModal} className="text-3xl text-black/30">×</button>
            </div>

            <div className="rounded-2xl bg-[#f0f2f5] p-4 text-sm mb-4">
              <div className="text-black/60 text-xs mb-1">PRE-FILLED MESSAGE (auto-generated):</div>
              <div className="font-medium leading-snug">“{getPrefilledMessage(selectedProduct?.title)}”</div>
            </div>

            <div className="text-xs text-black/50 mb-4">This is what your customer will see pre-filled when they tap the button. Perfect for fast checkout inquiries.</div>

            <div className="flex gap-3">
              <button 
                onClick={simulateSendMessage}
                className="flex-1 rounded-2xl py-3.5 text-sm font-semibold text-white active:opacity-90"
                style={{ backgroundColor: chatPlatform === 'messenger' ? '#0084FF' : '#25D366' }}
              >
                OPEN IN {chatPlatform.toUpperCase()} &amp; SEND
              </button>
              <button onClick={closeChatModal} className="flex-1 rounded-2xl border py-3.5 text-sm font-medium active:bg-zinc-50">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
